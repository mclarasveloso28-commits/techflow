
@app.route("/receber", methods=["POST"])
def receber():
    dados = request.get_json()

    uid = dados["uid"]

    print("Cartão recebido:", uid)

    return jsonify({
        "mensagem": "Cartão recebido!",
        "uid": uid
    })
