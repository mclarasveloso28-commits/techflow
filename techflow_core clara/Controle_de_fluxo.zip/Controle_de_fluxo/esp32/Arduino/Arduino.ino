#include <WiFi.h>
#include <HTTPClient.h>
#include <SPI.h>
#include <MFRC522.h>

// ====== CONFIGURE AQUI ======
const char* WIFI_SSID  = "NOME_DO_SEU_WIFI";
const char* WIFI_SENHA = "SENHA_DO_WIFI";
const char* SERVIDOR   = "http://192.168.0.10:3000/api/registro";
// ============================

#define SS_PIN 5
#define RST_PIN 22
#define BUZZER 27

MFRC522 rfid(SS_PIN, RST_PIN);
unsigned long ultimaLeitura = 0;

void bip(int vezes) {
  for (int i = 0; i < vezes; i++) {
    digitalWrite(BUZZER, HIGH); delay(80);
    digitalWrite(BUZZER, LOW);  delay(80);
  }
}

void conectarWiFi() {
  WiFi.begin(WIFI_SSID, WIFI_SENHA);
  Serial.print("Conectando ao Wi-Fi");
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
  Serial.println("\nConectado! IP: " + WiFi.localIP().toString());
}

void setup() {
  Serial.begin(115200);
  pinMode(BUZZER, OUTPUT);
  SPI.begin();
  rfid.PCD_Init();
  conectarWiFi();
  Serial.println("Aproxime o cartao...");
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) conectarWiFi();

  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) return;
  if (millis() - ultimaLeitura < 2000) { rfid.PICC_HaltA(); return; }
  ultimaLeitura = millis();

  String uid = "";
  for (byte i = 0; i < rfid.uid.size; i++) {
    if (rfid.uid.uidByte[i] < 0x10) uid += "0";
    uid += String(rfid.uid.uidByte[i], HEX);
  }
  uid.toUpperCase();
  Serial.println("UID: " + uid);

  HTTPClient http;
  http.begin(SERVIDOR);
  http.addHeader("Content-Type", "application/json");
  int codigo = http.POST("{\"uid\":\"" + uid + "\"}");

  if (codigo == 200) {
    Serial.println("Resposta: " + http.getString());
    bip(1);
  } else {
    Serial.println("Erro HTTP: " + String(codigo));
    bip(3);
  }
  http.end();

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
}